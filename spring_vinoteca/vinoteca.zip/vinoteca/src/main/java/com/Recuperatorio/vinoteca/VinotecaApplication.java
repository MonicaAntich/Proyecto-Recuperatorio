package com.Recuperatorio.vinoteca;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VinotecaApplication {

	public static void main(String[] args) {
		SpringApplication.run(VinotecaApplication.class, args);
	}

}
