package com.Recuperatorio.vinoteca;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VinotecaApplicationTests {

	@Test
	void contextLoads() {
	}

}
